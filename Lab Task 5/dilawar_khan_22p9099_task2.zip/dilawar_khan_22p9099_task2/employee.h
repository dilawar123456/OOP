#include <iostream>
using namespace std;
class employee
{ 
    int id;
    string name;
    string title;
    int hrs;
    public:
    void setid(int i);
    void setname(string n);
    void settitle(string t);
    void sethrs(int h);
    int getid();
    string getname();
    string gettitle();
    int gethrs();
    double calc_Salary(int hrs, double hourly_rate);
    employee();
    employee(int i,string n,string t,int h);
};