#include <iostream>
#include "employee.h"
using namespace std;
void employee::setid(int i)
{
    id=i;
}
void employee::setname(string n)
{
    name=n;
}
void employee::settitle(string t)
{
    title=t;
}
void employee::sethrs(int h)
{
    hrs=h;
}
int employee::getid()
{
    return id;

}
string employee::getname()
{
    return name;

}
string employee::gettitle()
{
    return title;
}
int employee::gethrs()
{
    return hrs;
}
double employee::calc_Salary(int hrs, double hourly_rate)
{
    double salary;
    int hr1;
    if(hrs<=40)
    {
        salary=hrs*hourly_rate;
    }
    else if(hrs>40)
    {
        hr1=40;
        hrs=hrs-hr1;
        salary=(hr1*hourly_rate)+(hrs*(hourly_rate*2));

    }
    return salary;
}
employee::employee()
{
    id=9099;
    name="employee";
    title="";
    hrs=0;
}
employee::employee(int i,string n,string t,int h)
{
    id=i;
    name=n;
    title=t;
    hrs=h;
}