#include <iostream>
#include <string>
#include "employee.h"
using namespace std;
int main ()
{
    int id;
    int size;
    string name;
    string title;
    int hrs;
    int hourly_pay;

    cout<<"Enter the number of employees"<<endl;
    cin>>size;
    employee e[size];
    double salary[size];
    for(int i=0;i<size;i++)
    {
        cout<<"Enter ID of employee "<<i+1<<endl;
        cin>>id;
        e[i].setid(id);
        cin.ignore();
        cout<<"Enter the name of employee "<<i+1<<endl;
       getline(cin,name);
        e[i].setname(name);
        cout<<"Enter the Job title of employee "<<i+1<<endl;
      getline(cin,title);
        e[i].settitle(title);
        cout<<"Enter the hours of work done by employee "<<i+1<<endl;
        cin>>hrs;
        cout<<"Enter the hourly pay of employee"<<i+1<<endl;
        cin>>hourly_pay;
        salary[i]=e[i].calc_Salary(hrs,hourly_pay);

    }
    for(int i=0;i<size;i++)
    {
        name=e[i].getname();
        cout<<"The salary of "<<name<<" is "<<salary[i]<<endl;
    }
}