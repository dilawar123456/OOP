#include <iostream>
using namespace std;
class inventory
{
int id;
string name;
int price;
int quantity;

public:

void setid(int i);
void setname(string n);
void setprice(int p);
void setquantity(int q);
string getname();
int getprice();
int getid();
int getquantity();
void showdata();
inventory(int i, string n,int p, int q);
inventory();
~inventory();




};
