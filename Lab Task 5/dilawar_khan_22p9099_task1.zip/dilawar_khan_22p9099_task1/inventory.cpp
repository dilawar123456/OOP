#include <iostream>
using namespace std;
#include "inventory.h"
void inventory::setid(int i)
{
    id=i;
}
void inventory::setname(string n)
{
    name=n;
}
void inventory::setprice(int p)
{
    price=p;
}
void inventory::setquantity(int q)
{
    quantity=q;
}
string inventory::getname()
{
    return name;
}
int inventory::getprice()
{
    return price;
}
int inventory::getid()
{
    return id;
}
int inventory::getquantity()
{
    return quantity;
}
void inventory::showdata()
{
    cout<<"------------------------"<<endl;
    cout<<"ID : "<<id<<endl;
    cout<<"Name : "<<name<<endl;
    cout<<"Price : "<<price<<endl;
    cout<<"Quantity : "<<quantity<<endl;
}

inventory::inventory()
{
    
    id=9099;
    name="item";
    price=00;
    quantity=00;
}
inventory::inventory(int i, string n,int p, int q)
{
    
    id=i;
    name=n;
    price=p;
    quantity=q;
}
inventory::~inventory()
{
    cout<<"Object Destroyed"<<endl;
}