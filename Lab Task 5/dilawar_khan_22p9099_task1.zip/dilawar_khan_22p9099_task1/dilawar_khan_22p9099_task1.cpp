#include <iostream>
#include <string>
#include "inventory.h"
using namespace std;
void Display(inventory v1[],int size);
void update(inventory v1[]);
void search_for_items(inventory v1[],int size);
int main ()
{
    int size;
    int id;
    string name;
    int price;
    int quantity;
    int x;
    cout<<"Enter the total number of items to store"<<endl;
    cin>>size;
     inventory v1[size];
     for(int i=0;i<size;i++)
     {
        cout<<"Enter uinque ID of item "<<i+1<<endl;
        cin>>id;
        v1[i].setid(id);
        cin.ignore();
        cout<<"Enter name of item "<<i+1<<endl;
        getline(cin,name);
        v1[i].setname(name);
        cout<<"Enter the price of item "<<i+1<<endl;
        cin>>price;
        v1[i].setprice(price);
        cout<<"Enter the quantity of item "<<i+1<<endl;
        cin>>quantity;
        v1[i].setquantity(quantity);

     }

     while(x!=4)
     {
    cout<<"        PLease select an option      "<<endl;
    cout<<"1- Display Items "<<endl;
    cout<<"2- Update Item Details "<<endl;
    cout<<"3- Search for items by ID"<<endl;
    cout<<"4- Exit Program"<<endl;
    cin>>x;
    if (x==1)
    {
        Display(v1,size);
    }
    if (x==2)
    {
        update(v1);
    }
    if(x==3)
    {
        search_for_items(v1,size);
    }

     }

    return 0;
}
void Display(inventory v1[],int size)
{
    for(int i=0;i<size;i++)
    {
        v1[i].showdata();
    }
}
void update(inventory v1[])
{
    int choice;
    int p;
    int q;
    int item;
    cout<<"Enter the item you want to update"<<endl;
    cin>>item;
    cout<<"1- Update Price "<<endl;
    cout<<"2- Update Quantity"<<endl;
    cin>>choice;
    if(choice==1)
    {
        cout<<"Enter the new price "<<endl;
        cin>>p;
        v1[item-1].setprice(p);
       
    }
   else if (choice==2)
    {
        cout<<"Enter the new quantity"<<endl;
        cin>>q;
        v1[item-1].setquantity(q);
    }
    else{
        cout<<"Invalid Input"<<endl;
    }
}
void search_for_items(inventory v1[],int size)
{
    int flag=0;
    int search;
    cout<<"Enter the ID to search ";
    cin>>search;
    for(int i=0;i<size;i++)
    {
        if(search==v1[i].getid())
        {
            v1[i].showdata();
            flag=0;
            break;
        }
        else{
          flag=1;
        }
    }
    if (flag==1)
    {
          cout<<"Item not found"<<endl;
    }
}